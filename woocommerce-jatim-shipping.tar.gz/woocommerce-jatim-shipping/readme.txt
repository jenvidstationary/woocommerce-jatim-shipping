=== WooCommerce Jawa Timur Shipping ===
Contributors: jenvid
Tags: woocommerce, shipping, indonesia, jawa timur, jne, jnt, pos, rajaongkir
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Complete shipping solution for WooCommerce with Jawa Timur zone restrictions and multiple expedition services integration.

== Description ==

WooCommerce Jawa Timur Shipping provides a comprehensive shipping solution for e-commerce stores operating in the Jawa Timur region of Indonesia. The plugin integrates with major Indonesian shipping carriers (JNE, J&T, POS) and provides detailed zone restrictions with city, district, and postal code validation.

= Features =

* Multiple carrier integration (JNE, J&T, POS)
* Detailed Jawa Timur zone restrictions
  - City-level validation
  - District-level validation
  - Postal code validation
* Dynamic shipping rate calculation
* Advanced caching system for better performance
* Customizable handling fees per zone
* Comprehensive admin interface
* Full Indonesian language support
* RajaOngkir API integration

= Supported Shipping Methods =

* JNE
  - REG (Regular)
  - YES (Yakin Esok Sampai)
  - OKE (Ongkos Kirim Ekonomis)
* J&T Express
  - Regular
  - Express
* POS Indonesia
  - Standard
  - Express
  - Next Day

= Zone Management =

* Detailed city-level restrictions
* Optional district-level validation
* Optional postal code validation
* Custom handling fees per zone
* Zone-specific service availability

= Advanced Features =

* Real-time rate calculation
* Smart caching system
* Multiple origin points
* Custom handling fees
* Service-specific restrictions
* Detailed shipping logs
* Performance optimization
* Debug mode for troubleshooting

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/woocommerce-jatim-shipping`, or install through WordPress plugins screen
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to WooCommerce > Settings > Shipping
4. Configure your shipping zones and add "Jawa Timur Shipping"
5. Enter your API credentials for each carrier
6. Configure zone restrictions and handling fees

= Requirements =

* WordPress 5.0 or higher
* WooCommerce 3.0 or higher
* PHP 7.2 or higher
* JNE API credentials

== Frequently Asked Questions ==

= How do I get API credentials for the shipping carriers? =

You can obtain API credentials by registering at:
* JNE: [JNE Developer Portal](https://www.jne.co.id/id/developer/api)
* J&T: [J&T Developer Center](https://developer.jet.co.id)
* POS: [POS Indonesia Developer](https://developer.posindonesia.co.id)
* RajaOngkir: [RajaOngkir](https://rajaongkir.com/dokumentasi)

= Is this plugin limited to Jawa Timur only? =

While the plugin is optimized for Jawa Timur with detailed zone restrictions, you can use it for other regions as well. The zone restrictions are optional and can be disabled.

= Which shipping services are supported? =

We support multiple services from each carrier:
* JNE: REG, YES, OKE
* J&T: Regular, Express
* POS: Standard, Express, Next Day

= How does the caching system work? =

The plugin implements a smart caching system that:
* Caches rates for 12 hours by default
* Automatically invalidates cache when settings change
* Supports manual cache clearing
* Implements zone-specific cache rules

== Screenshots ==

1. Settings page
2. Shipping rate display
3. Order tracking information
4. Admin tracking management
5. Zone restriction settings

== Changelog ==

= 1.0.0 =
* Initial release
* JNE API integration
* Support for REG, YES, and OKE services
* Dynamic rate calculation
* Rate caching system
* Jawa Timur zone restriction
* Shipment tracking
* Order tracking display
* Admin tracking management
* Indonesian language support

== Upgrade Notice ==

= 1.0.0 =
Initial release with full JNE shipping integration and Jawa Timur zone support.

== Additional Information ==

= Documentation =

Detailed documentation is available at [GitHub](https://github.com/jenvid/woocommerce-jatim-shipping/wiki).

= Support =

For support, please visit:
* Website: [https://sub-webtestjenvid.com](https://sub-webtestjenvid.com)
* GitHub: [https://github.com/jenvid/woocommerce-jatim-shipping](https://github.com/jenvid/woocommerce-jatim-shipping)

= Contributing =

Development happens on [GitHub](https://github.com/jenvid/woocommerce-jatim-shipping). Pull requests welcome.

= Credits =

* JNE PHP Package by [yusufthedragon](https://github.com/yusufthedragon/jne-php)
* Icons by [Font Awesome](https://fontawesome.com)

== Privacy Policy ==

This plugin communicates with shipping carrier APIs to calculate shipping rates and track shipments. No personal data is stored or shared beyond what is required for these functions.

Data collected includes:
* Shipping addresses
* Order weights
* Tracking numbers

For more information, see our [privacy policy](https://sub-webtestjenvid.com/privacy).
