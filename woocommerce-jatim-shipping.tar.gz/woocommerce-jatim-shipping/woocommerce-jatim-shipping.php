<?php
/**
 * Plugin Name: WooCommerce Jawa Timur Shipping
 * Plugin URI: https://sub-webtestjenvid.com
 * Description: WooCommerce shipping plugin with Jawa Timur zone restrictions and integrated expedition services
 * Version: 1.0.0
 * Author: Jenvid
 * Author URI: https://sub-webtestjenvid.com
 * Text Domain: wc-jatim-shipping
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.2
 * WC requires at least: 6.0
 * WC tested up to: 8.5
 *
 * @package WC_Jatim_Shipping
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WC_JATIM_SHIPPING_VERSION', '1.0.0');
define('WC_JATIM_SHIPPING_FILE', __FILE__);
define('WC_JATIM_SHIPPING_PATH', plugin_dir_path(__FILE__));
define('WC_JATIM_SHIPPING_URL', plugin_dir_url(__FILE__));

/**
 * Check if WooCommerce is active
 */
function wc_jatim_shipping_init() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'wc_jatim_shipping_wc_missing_notice');
        return;
    }

    // Load plugin files
    require_once WC_JATIM_SHIPPING_PATH . 'includes/class-jawa-timur-zones.php';
    require_once WC_JATIM_SHIPPING_PATH . 'includes/shipping-api.php';
    require_once WC_JATIM_SHIPPING_PATH . 'includes/class-wc-indo-shipping.php';
    require_once WC_JATIM_SHIPPING_PATH . 'includes/admin-settings.php';

    // Load integrations
    if (class_exists('Woostify_Pro')) {
        require_once WC_JATIM_SHIPPING_PATH . 'includes/integrations/class-woostify-integration.php';
    }

    // Declare HPOS compatibility
    if (!function_exists('wc_jatim_shipping_hpos_compatible')) {
        function wc_jatim_shipping_hpos_compatible() {
            if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('orders_cache_enabled', __FILE__, true);
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('product_block_editor', __FILE__, true);
            }
        }
        add_action('before_woocommerce_init', 'wc_jatim_shipping_hpos_compatible');
    }

    // Register activation hook for Woostify compatibility
    register_activation_hook(__FILE__, 'wc_jatim_shipping_check_woostify');

    // Add shipping method
    add_filter('woocommerce_shipping_methods', 'wc_jatim_shipping_add_method');

    // Load translations
    add_action('init', 'wc_jatim_shipping_load_textdomain');
}
add_action('plugins_loaded', 'wc_jatim_shipping_init');

/**
 * Add shipping method to WooCommerce
 */
function wc_jatim_shipping_add_method($methods) {
    $methods['jatim_shipping'] = 'WC_Indo_Shipping_Method';
    return $methods;
}

/**
 * Load plugin text domain
 */
function wc_jatim_shipping_load_textdomain() {
    load_plugin_textdomain(
        'wc-jatim-shipping',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages/'
    );
}

/**
 * Check Woostify compatibility on activation
 */
function wc_jatim_shipping_check_woostify() {
    if (class_exists('Woostify_Pro')) {
        // Add theme compatibility data
        $theme_data = get_option('woostify_pro_options', array());
        $theme_data['shipping_integration'] = true;
        update_option('woostify_pro_options', $theme_data);
    }
}

/**
 * Display notice if WooCommerce is not active
 */
function wc_jatim_shipping_wc_missing_notice() {
    ?>
    <div class="error">
        <p><?php
        printf(
            /* translators: %s: WooCommerce link */
            esc_html__('WooCommerce Jawa Timur Shipping requires WooCommerce to be installed and active. You can download %s here.', 'wc-jatim-shipping'),
            '<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>'
        );
        ?></p>
    </div>
    <?php
}

/**
 * Installation hook
 */
function wc_jatim_shipping_install() {
    // Create necessary database tables if needed
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    // Example table for caching shipping rates
    $table_name = $wpdb->prefix . 'wc_jatim_shipping_rates';
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        origin varchar(50) NOT NULL,
        destination varchar(50) NOT NULL,
        service varchar(20) NOT NULL,
        weight decimal(10,2) NOT NULL,
        cost decimal(12,2) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        expires_at datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY origin_dest_service (origin,destination,service)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Set default options
    $default_options = array(
        'enable_zone_restriction' => 'yes',
        'enable_district_restriction' => 'no',
        'enable_postal_restriction' => 'no',
        'handling_fee_jatim' => '0',
        'shipping_services' => array('jne_reg', 'jne_yes', 'jnt_regular')
    );

    add_option('wc_jatim_shipping_settings', $default_options);
}
register_activation_hook(__FILE__, 'wc_jatim_shipping_install');

/**
 * Uninstallation hook
 */
function wc_jatim_shipping_uninstall() {
    // Remove plugin options
    delete_option('wc_jatim_shipping_settings');

    // Remove database tables
    global $wpdb;
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}wc_jatim_shipping_rates");
}
register_uninstall_hook(__FILE__, 'wc_jatim_shipping_uninstall');
