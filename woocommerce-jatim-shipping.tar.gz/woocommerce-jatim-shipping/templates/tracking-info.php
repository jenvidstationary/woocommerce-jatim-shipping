<?php
/**
 * JNE Tracking Information Template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/tracking-info.php.
 *
 * Variables available:
 * - $tracking_number: JNE tracking number
 * - $tracking_info: Array of tracking information
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="jne-tracking-info">
    <h2><?php esc_html_e('JNE Tracking Information', 'indo-shipping'); ?></h2>
    
    <table class="woocommerce-table tracking-details">
        <tbody>
            <tr>
                <th><?php esc_html_e('Tracking Number:', 'indo-shipping'); ?></th>
                <td>
                    <?php echo esc_html($tracking_number); ?>
                    <a href="https://www.jne.co.id/tracking/trace" 
                       target="_blank" 
                       class="button button-small">
                        <?php esc_html_e('Track on JNE Website', 'indo-shipping'); ?>
                    </a>
                </td>
            </tr>
            
            <tr>
                <th><?php esc_html_e('Status:', 'indo-shipping'); ?></th>
                <td>
                    <span class="tracking-status status-<?php echo esc_attr(strtolower($tracking_info['status'])); ?>">
                        <?php echo esc_html($tracking_info['status']); ?>
                    </span>
                </td>
            </tr>
            
            <?php if (!empty($tracking_info['origin'])): ?>
                <tr>
                    <th><?php esc_html_e('Origin:', 'indo-shipping'); ?></th>
                    <td><?php echo esc_html($tracking_info['origin']); ?></td>
                </tr>
            <?php endif; ?>
            
            <?php if (!empty($tracking_info['destination'])): ?>
                <tr>
                    <th><?php esc_html_e('Destination:', 'indo-shipping'); ?></th>
                    <td><?php echo esc_html($tracking_info['destination']); ?></td>
                </tr>
            <?php endif; ?>
            
            <?php if (!empty($tracking_info['service'])): ?>
                <tr>
                    <th><?php esc_html_e('Service:', 'indo-shipping'); ?></th>
                    <td><?php echo esc_html($tracking_info['service']); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php if (!empty($tracking_info['history'])): ?>
        <h3><?php esc_html_e('Tracking History', 'indo-shipping'); ?></h3>
        <table class="woocommerce-table tracking-history">
            <thead>
                <tr>
                    <th><?php esc_html_e('Date', 'indo-shipping'); ?></th>
                    <th><?php esc_html_e('Status', 'indo-shipping'); ?></th>
                    <th><?php esc_html_e('Location', 'indo-shipping'); ?></th>
                    <th><?php esc_html_e('Description', 'indo-shipping'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tracking_info['history'] as $history): ?>
                    <tr>
                        <td><?php echo esc_html($history['date']); ?></td>
                        <td>
                            <span class="status-<?php echo esc_attr(strtolower($history['status'])); ?>">
                                <?php echo esc_html($history['status']); ?>
                            </span>
                        </td>
                        <td><?php echo esc_html($history['location']); ?></td>
                        <td><?php echo esc_html($history['description']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<style>
.jne-tracking-info {
    margin: 2em 0;
    padding: 1em;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.jne-tracking-info h2 {
    margin-bottom: 1em;
}

.tracking-details {
    margin-bottom: 2em;
}

.tracking-details th {
    padding: 0.5em;
    text-align: left;
    width: 150px;
}

.tracking-details td {
    padding: 0.5em;
}

.tracking-status {
    display: inline-block;
    padding: 0.25em 0.5em;
    border-radius: 3px;
    font-weight: bold;
}

.status-delivered {
    background-color: #c6e1c6;
    color: #5b841b;
}

.status-in_transit {
    background-color: #c8d7e1;
    color: #2e4453;
}

.status-picked_up {
    background-color: #f8dda7;
    color: #94660c;
}

.status-pending {
    background-color: #e5e5e5;
    color: #777;
}

.tracking-history {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1em;
}

.tracking-history th,
.tracking-history td {
    padding: 0.5em;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.tracking-history th {
    background-color: #f8f8f8;
    font-weight: bold;
}

.button.button-small {
    margin-left: 1em;
    font-size: 0.9em;
    vertical-align: middle;
}
</style>
