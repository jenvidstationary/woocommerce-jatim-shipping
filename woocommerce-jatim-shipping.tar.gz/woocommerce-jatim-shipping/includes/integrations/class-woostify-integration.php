<?php
/**
 * Woostify Theme Integration
 */

if (!defined('ABSPATH')) {
    exit;
}

class WC_Jatim_Shipping_Woostify_Integration {
    /**
     * Constructor
     */
    private $woostify_version = '2.4.0';

    public function __construct() {
        // Add theme compatibility
        add_action('after_setup_theme', array($this, 'declare_compatibility'));
        
        // Add custom styling for Woostify checkout
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        
        // Add shipping method display customization
        add_filter('woocommerce_cart_shipping_method_full_label', array($this, 'customize_shipping_label'), 10, 2);
        
        // Add shipping fields customization for Woostify checkout
        add_filter('woocommerce_shipping_fields', array($this, 'customize_shipping_fields'));
        
        // Add district field to address format
        add_filter('woocommerce_localisation_address_formats', array($this, 'add_district_format'));
        add_filter('woocommerce_formatted_address_replacements', array($this, 'add_district_replacement'), 10, 2);

        // Add Woostify 2.4.0 specific hooks
        add_action('woostify_pro_checkout_before_shipping_address', array($this, 'add_shipping_notice'));
        add_filter('woostify_pro_checkout_address_fields', array($this, 'modify_address_fields'));
        add_filter('woostify_shipping_package_name', array($this, 'customize_package_name'));
    }

    /**
     * Add shipping notice for Woostify Pro checkout
     */
    public function add_shipping_notice() {
        if (!defined('WOOSTIFY_PRO_VERSION') || version_compare(WOOSTIFY_PRO_VERSION, $this->woostify_version, '<')) {
            return;
        }

        echo '<div class="woocommerce-shipping-notice">';
        echo esc_html__('Shipping rates will be calculated based on your location in Jawa Timur.', 'wc-jatim-shipping');
        echo '</div>';
    }

    /**
     * Modify address fields for Woostify Pro
     */
    public function modify_address_fields($fields) {
        if (!defined('WOOSTIFY_PRO_VERSION') || version_compare(WOOSTIFY_PRO_VERSION, $this->woostify_version, '<')) {
            return $fields;
        }

        // Customize district field
        if (isset($fields['shipping_district'])) {
            $fields['shipping_district']['class'] = array('form-row-wide', 'woostify-district-field');
            $fields['shipping_district']['priority'] = 45; // After city field
        }

        // Customize city field
        if (isset($fields['shipping_city'])) {
            $fields['shipping_city']['class'] = array('form-row-first', 'woostify-city-field');
            $fields['shipping_city']['custom_attributes'] = array(
                'data-version' => $this->woostify_version
            );
        }

        return $fields;
    }

    /**
     * Customize shipping package name for Woostify
     */
    public function customize_package_name($name) {
        return __('Shipping to Jawa Timur', 'wc-jatim-shipping');
    }

    /**
     * Declare compatibility with Woostify theme
     */
    public function declare_compatibility() {
        if (!defined('WOOSTIFY_PRO_VERSION')) {
            return;
        }

        if (version_compare(WOOSTIFY_PRO_VERSION, $this->woostify_version, '>=')) {
            add_theme_support('woostify-pro', array(
                'shipping' => true,
                'checkout' => true,
                'version' => $this->woostify_version
            ));

            // Add Woostify Pro specific features
            add_theme_support('woostify-checkout-style', array(
                'two-columns' => true,
                'shipping-calculator' => true,
                'address-validation' => true
            ));
        }
    }

    /**
     * Enqueue custom styles for Woostify
     */
    public function enqueue_styles() {
        if (!class_exists('Woostify_Pro')) {
            return;
        }

        wp_enqueue_style(
            'wc-jatim-shipping-woostify',
            plugins_url('assets/css/woostify.css', WC_JATIM_SHIPPING_FILE),
            array('woostify-pro'),
            WC_JATIM_SHIPPING_VERSION
        );
    }

    /**
     * Customize shipping method label for Woostify
     */
    public function customize_shipping_label($label, $method) {
        if (!class_exists('Woostify_Pro')) {
            return $label;
        }

        // Add estimated delivery time
        if (strpos($method->id, 'jatim_shipping') !== false) {
            $delivery_time = $this->get_delivery_time($method->id);
            if ($delivery_time) {
                $label .= sprintf(
                    '<br><small class="delivery-time">%s %s</small>',
                    __('Estimated delivery:', 'wc-jatim-shipping'),
                    $delivery_time
                );
            }
        }

        return $label;
    }

    /**
     * Get delivery time for shipping method
     */
    private function get_delivery_time($method_id) {
        $delivery_times = array(
            'jne_reg' => '2-3 ' . __('days', 'wc-jatim-shipping'),
            'jne_yes' => '1 ' . __('day', 'wc-jatim-shipping'),
            'jne_oke' => '3-4 ' . __('days', 'wc-jatim-shipping'),
            'jnt_regular' => '2-3 ' . __('days', 'wc-jatim-shipping'),
            'jnt_express' => '1-2 ' . __('days', 'wc-jatim-shipping'),
            'pos_standard' => '3-4 ' . __('days', 'wc-jatim-shipping'),
            'pos_express' => '1-2 ' . __('days', 'wc-jatim-shipping'),
            'pos_nextday' => '1 ' . __('day', 'wc-jatim-shipping'),
        );

        return isset($delivery_times[$method_id]) ? $delivery_times[$method_id] : '';
    }

    /**
     * Customize shipping fields for Woostify checkout
     */
    public function customize_shipping_fields($fields) {
        if (!class_exists('Woostify_Pro')) {
            return $fields;
        }

        // Add district field
        $fields['shipping_district'] = array(
            'label' => __('District', 'wc-jatim-shipping'),
            'required' => true,
            'class' => array('form-row-wide'),
            'priority' => 65,
            'type' => 'select',
            'options' => array('' => __('Select district', 'wc-jatim-shipping')),
        );

        // Customize city field
        if (isset($fields['shipping_city'])) {
            $fields['shipping_city']['class'] = array('form-row-first');
            $fields['shipping_city']['type'] = 'select';
            $fields['shipping_city']['options'] = array('' => __('Select city', 'wc-jatim-shipping'));
        }

        // Customize postcode field
        if (isset($fields['shipping_postcode'])) {
            $fields['shipping_postcode']['class'] = array('form-row-last');
            $fields['shipping_postcode']['priority'] = 66;
        }

        return $fields;
    }

    /**
     * Add district to address format
     */
    public function add_district_format($formats) {
        foreach ($formats as $key => $format) {
            $formats[$key] = str_replace('{city}', '{city}, {district}', $format);
        }
        return $formats;
    }

    /**
     * Add district replacement
     */
    public function add_district_replacement($replacements, $args) {
        $replacements['{district}'] = isset($args['district']) ? $args['district'] : '';
        return $replacements;
    }
}

// Initialize Woostify integration
new WC_Jatim_Shipping_Woostify_Integration();
