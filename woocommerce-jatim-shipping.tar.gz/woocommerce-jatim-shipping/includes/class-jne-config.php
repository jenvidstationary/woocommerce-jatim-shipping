<?php
/**
 * JNE Shipping Configuration Handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class JNE_Config {
    private static $instance = null;
    private $config = [];

    /**
     * Constructor
     */
    private function __construct() {
        $this->load_env();
        $this->load_wp_options();
    }

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Load environment variables
     */
    private function load_env() {
        $env_file = JNE_SHIPPING_PLUGIN_DIR . '.env';
        if (file_exists($env_file)) {
            $lines = file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
                    list($key, $value) = explode('=', $line, 2);
                    $key = trim($key);
                    $value = trim($value);
                    
                    // Remove quotes if present
                    if (preg_match('/^(["\']).*\1$/', $value)) {
                        $value = substr($value, 1, -1);
                    }
                    
                    $this->config[$key] = $value;
                }
            }
        }
    }

    /**
     * Load WordPress options
     */
    private function load_wp_options() {
        $wp_options = get_option('jne_shipping_settings', []);
        foreach ($wp_options as $key => $value) {
            $this->config['WP_' . strtoupper($key)] = $value;
        }
    }

    /**
     * Get configuration value
     */
    public function get($key, $default = null) {
        // First check WordPress options
        $wp_key = 'WP_' . strtoupper($key);
        if (isset($this->config[$wp_key])) {
            return $this->config[$wp_key];
        }
        
        // Then check environment variables
        if (isset($this->config[$key])) {
            return $this->config[$key];
        }
        
        return $default;
    }

    /**
     * Get all configuration values
     */
    public function get_all() {
        return $this->config;
    }

    /**
     * Get API configuration
     */
    public function get_api_config() {
        return [
            'api_key' => $this->get('JNE_API_KEY'),
            'username' => $this->get('JNE_USERNAME'),
            'api_url' => $this->get('JNE_API_URL', 'https://api.jne.co.id/'),
            'api_version' => $this->get('JNE_API_VERSION', 'v1')
        ];
    }

    /**
     * Get origin settings
     */
    public function get_origin_settings() {
        return [
            'city_code' => $this->get('JNE_ORIGIN_CITY'),
            'city_name' => $this->get('JNE_ORIGIN_NAME')
        ];
    }

    /**
     * Get cache settings
     */
    public function get_cache_settings() {
        return [
            'enabled' => filter_var($this->get('CACHE_ENABLED', true), FILTER_VALIDATE_BOOLEAN),
            'duration' => (int)$this->get('CACHE_DURATION', 43200)
        ];
    }

    /**
     * Get zone settings
     */
    public function get_zone_settings() {
        return [
            'restriction_enabled' => filter_var($this->get('ENABLE_ZONE_RESTRICTION', true), FILTER_VALIDATE_BOOLEAN),
            'restricted_zone' => $this->get('RESTRICTED_ZONE', 'Jawa Timur')
        ];
    }

    /**
     * Get debug settings
     */
    public function get_debug_settings() {
        return [
            'debug_mode' => filter_var($this->get('DEBUG_MODE', false), FILTER_VALIDATE_BOOLEAN),
            'log_enabled' => filter_var($this->get('DEBUG_LOG_ENABLED', true), FILTER_VALIDATE_BOOLEAN)
        ];
    }

    /**
     * Get enabled services
     */
    public function get_enabled_services() {
        $services = $this->get('ENABLED_SERVICES', 'REG,YES,OKE');
        return array_map('trim', explode(',', $services));
    }

    /**
     * Get weight settings
     */
    public function get_weight_settings() {
        return [
            'unit' => $this->get('DEFAULT_WEIGHT_UNIT', 'kg'),
            'max_weight' => (float)$this->get('MAX_WEIGHT_PER_PACKAGE', 50)
        ];
    }

    /**
     * Get currency settings
     */
    public function get_currency_settings() {
        return [
            'currency' => $this->get('CURRENCY', 'IDR'),
            'thousand_separator' => $this->get('THOUSAND_SEPARATOR', '.'),
            'decimal_separator' => $this->get('DECIMAL_SEPARATOR', ','),
            'decimal_digits' => (int)$this->get('DECIMAL_DIGITS', 0)
        ];
    }

    /**
     * Get notification settings
     */
    public function get_notification_settings() {
        return [
            'admin_email' => $this->get('ADMIN_EMAIL'),
            'enabled' => filter_var($this->get('NOTIFICATION_ENABLED', true), FILTER_VALIDATE_BOOLEAN)
        ];
    }

    /**
     * Format currency
     */
    public function format_currency($amount) {
        $settings = $this->get_currency_settings();
        return number_format(
            $amount,
            $settings['decimal_digits'],
            $settings['decimal_separator'],
            $settings['thousand_separator']
        );
    }

    /**
     * Log debug message
     */
    public function log($message, $type = 'info') {
        $debug_settings = $this->get_debug_settings();
        if ($debug_settings['log_enabled']) {
            $log_message = sprintf(
                '[%s] [%s] %s',
                date('Y-m-d H:i:s'),
                strtoupper($type),
                is_array($message) || is_object($message) ? print_r($message, true) : $message
            );
            
            error_log($log_message . PHP_EOL, 3, JNE_SHIPPING_PLUGIN_DIR . 'debug.log');
        }
    }
}
