<?php
/**
 * JNE Shipping Rates Handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class JNE_Rates {
    private $config;
    private $api;

    /**
     * Constructor
     */
    public function __construct() {
        $this->config = JNE_Config::get_instance();
        $this->init_api();
    }

    /**
     * Initialize API
     */
    private function init_api() {
        $api_config = $this->config->get_api_config();
        $this->api = new Indo_Shipping_API(
            $api_config['api_key'],
            $api_config['username']
        );
    }

    /**
     * Calculate shipping rates
     */
    public function calculate_rates($package) {
        try {
            // Check zone restriction
            if ($this->should_restrict_zone() && !$this->is_valid_zone($package['destination'])) {
                $this->config->log('Destination not in allowed zone: ' . $package['destination']['city']);
                return false;
            }

            // Calculate total weight
            $weight = $this->calculate_total_weight($package['contents']);
            
            // Check weight limits
            $weight_settings = $this->config->get_weight_settings();
            if ($weight > $weight_settings['max_weight']) {
                $this->config->log("Weight exceeds maximum limit: {$weight}kg");
                return false;
            }

            // Get origin settings
            $origin = $this->config->get_origin_settings();
            
            // Try to get cached rates
            $rates = $this->get_cached_rates($origin['city_code'], $package['destination']['city'], $weight);
            
            if (!$rates) {
                // Get fresh rates from API
                $rates = $this->get_fresh_rates($origin['city_code'], $package['destination']['city'], $weight);
                
                if ($rates) {
                    // Cache the rates
                    $this->cache_rates($origin['city_code'], $package['destination']['city'], $weight, $rates);
                }
            }

            return $this->filter_enabled_services($rates);

        } catch (Exception $e) {
            $this->config->log('Rate calculation error: ' . $e->getMessage(), 'error');
            return false;
        }
    }

    /**
     * Calculate total weight
     */
    private function calculate_total_weight($items) {
        $total_weight = 0;
        foreach ($items as $item) {
            $product = $item['data'];
            $weight = (float)$product->get_weight();
            $quantity = (int)$item['quantity'];
            
            // Convert weight to kg if needed
            if ($product->get_weight_unit() !== 'kg') {
                $weight = $this->convert_weight_to_kg($weight, $product->get_weight_unit());
            }
            
            $total_weight += $weight * $quantity;
        }
        return $total_weight;
    }

    /**
     * Convert weight to kg
     */
    private function convert_weight_to_kg($weight, $unit) {
        switch (strtolower($unit)) {
            case 'g':
                return $weight / 1000;
            case 'lbs':
                return $weight * 0.45359237;
            case 'oz':
                return $weight * 0.02834952;
            default:
                return $weight;
        }
    }

    /**
     * Check if zone restriction should be applied
     */
    private function should_restrict_zone() {
        $zone_settings = $this->config->get_zone_settings();
        return $zone_settings['restriction_enabled'];
    }

    /**
     * Check if destination is in valid zone
     */
    private function is_valid_zone($destination) {
        return $this->api->validate_jawa_timur_address($destination['city']);
    }

    /**
     * Get cached shipping rates
     */
    private function get_cached_rates($origin, $destination, $weight) {
        $cache_settings = $this->config->get_cache_settings();
        if (!$cache_settings['enabled']) {
            return false;
        }

        return $this->api->get_cached_rates($origin, $destination, $weight, 'jne');
    }

    /**
     * Get fresh rates from API
     */
    private function get_fresh_rates($origin, $destination, $weight) {
        $rates = $this->api->get_jne_rates($origin, $destination, $weight);
        
        if (!$rates) {
            $this->config->log('Failed to get rates from JNE API', 'error');
            return false;
        }

        return $rates;
    }

    /**
     * Cache shipping rates
     */
    private function cache_rates($origin, $destination, $weight, $rates) {
        $cache_settings = $this->config->get_cache_settings();
        if ($cache_settings['enabled']) {
            $this->api->set_cached_rates($origin, $destination, $weight, 'jne', $rates);
        }
    }

    /**
     * Filter rates to only include enabled services
     */
    private function filter_enabled_services($rates) {
        if (!$rates) {
            return false;
        }

        $enabled_services = $this->config->get_enabled_services();
        $filtered_rates = array();

        foreach ($rates as $service_code => $rate_data) {
            if (in_array($service_code, $enabled_services)) {
                $filtered_rates[$service_code] = $rate_data;
            }
        }

        return !empty($filtered_rates) ? $filtered_rates : false;
    }

    /**
     * Format rate label
     */
    public function format_rate_label($service_code, $service_name, $etd = '') {
        $label = $service_name;
        
        if (!empty($etd)) {
            $label .= ' (' . $etd . ')';
        }

        return apply_filters('jne_shipping_rate_label', $label, $service_code, $service_name, $etd);
    }

    /**
     * Format rate cost
     */
    public function format_rate_cost($cost) {
        return $this->config->format_currency($cost);
    }

    /**
     * Get service details
     */
    public function get_service_details($service_code) {
        $services = [
            'reg' => [
                'name' => 'JNE REG (Regular)',
                'description' => 'Regular delivery service',
                'default_etd' => '2-3 days'
            ],
            'yes' => [
                'name' => 'JNE YES (Yakin Esok Sampai)',
                'description' => 'Next day delivery service',
                'default_etd' => '1 day'
            ],
            'oke' => [
                'name' => 'JNE OKE (Ongkos Kirim Ekonomis)',
                'description' => 'Economic delivery service',
                'default_etd' => '3-4 days'
            ]
        ];

        return isset($services[$service_code]) ? $services[$service_code] : false;
    }
}
