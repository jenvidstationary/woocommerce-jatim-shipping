<?php
/**
 * Shipping API Integration Handler
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . '../vendor/autoload.php';

use Yusufthedragon\JNE\JNE;
use Yusufthedragon\JNE\Resources\Price;

class Indo_Shipping_API {
    private $jne_api_key;
    private $jne_username;
    private $jne_client;

    public function __construct($jne_api_key, $jne_username) {
        $this->jne_api_key = $jne_api_key;
        $this->jne_username = $jne_username;
        
        // Initialize JNE client if credentials are provided
        if (!empty($jne_api_key) && !empty($jne_username)) {
            $this->jne_client = new JNE($jne_api_key, $jne_username);
        }
    }

    /**
     * Get JNE shipping rates
     */
    public function get_jne_rates($origin, $destination, $weight) {
        try {
            if (!$this->jne_client) {
                throw new Exception('JNE client not initialized. Check API credentials.');
            }

            $price = new Price($this->jne_client);
            
            $params = [
                'from' => $origin,
                'thru' => $destination,
                'weight' => $weight
            ];

            $response = $price->calculate($params);

            if (!isset($response['price']) || empty($response['price'])) {
                throw new Exception('No shipping rates available for this route.');
            }

            $rates = [];
            foreach ($response['price'] as $service) {
                $service_code = strtolower($service['service_code']);
                $rates[$service_code] = [
                    'service' => $service['service_display'],
                    'cost' => $service['price'],
                    'etd' => $service['etd'] ?? '',
                    'description' => $service['service_description'] ?? ''
                ];
            }

            return $rates;

        } catch (Exception $e) {
            error_log('JNE API Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get cached shipping rates
     */
    public function get_cached_rates($origin, $destination, $weight, $courier) {
        if ($courier !== 'jne') {
            return false;
        }

        $cache_key = sprintf('jne_rate_%s_%s_%s', $origin, $destination, $weight);
        $cached = get_transient($cache_key);
        
        if ($cached !== false) {
            return $cached;
        }
        
        return false;
    }

    /**
     * Set cached shipping rates
     */
    public function set_cached_rates($origin, $destination, $weight, $courier, $rates) {
        if ($courier !== 'jne') {
            return;
        }

        $cache_key = sprintf('jne_rate_%s_%s_%s', $origin, $destination, $weight);
        set_transient($cache_key, $rates, HOUR_IN_SECONDS * 12); // Cache for 12 hours
    }

    /**
     * Validate if address is in Jawa Timur
     */
    public function validate_jawa_timur_address($city, $district = '', $postal_code = '') {
        require_once plugin_dir_path(__FILE__) . 'class-jawa-timur-zones.php';
        $zones = new Jawa_Timur_Zones();
        return $zones->validate_address($city, $district, $postal_code);
    }

    /**
     * Get supported districts for a city in Jawa Timur
     */
    public function get_jawa_timur_districts($city) {
        require_once plugin_dir_path(__FILE__) . 'class-jawa-timur-zones.php';
        $zones = new Jawa_Timur_Zones();
        return $zones->get_districts($city);
    }

    /**
     * Get supported postal codes for a city in Jawa Timur
     */
    public function get_jawa_timur_postal_codes($city) {
        require_once plugin_dir_path(__FILE__) . 'class-jawa-timur-zones.php';
        $zones = new Jawa_Timur_Zones();
        return $zones->get_postal_codes($city);
    }

    /**
     * Get all supported cities in Jawa Timur
     */
    public function get_jawa_timur_cities() {
        require_once plugin_dir_path(__FILE__) . 'class-jawa-timur-zones.php';
        $zones = new Jawa_Timur_Zones();
        return $zones->get_supported_cities();
    }

    /**
     * Get JNE origin cities
     */
    public function get_jne_origins() {
        try {
            if (!$this->jne_client) {
                throw new Exception('JNE client not initialized. Check API credentials.');
            }

            $response = $this->jne_client->getOrigins();
            
            if (!isset($response['origin']) || empty($response['origin'])) {
                throw new Exception('No origin cities available.');
            }

            return $response['origin'];

        } catch (Exception $e) {
            error_log('JNE API Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get JNE destination cities
     */
    public function get_jne_destinations($origin_code = '') {
        try {
            if (!$this->jne_client) {
                throw new Exception('JNE client not initialized. Check API credentials.');
            }

            $params = [];
            if (!empty($origin_code)) {
                $params['from'] = $origin_code;
            }

            $response = $this->jne_client->getDestinations($params);
            
            if (!isset($response['destination']) || empty($response['destination'])) {
                throw new Exception('No destination cities available.');
            }

            return $response['destination'];

        } catch (Exception $e) {
            error_log('JNE API Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Track JNE shipment
     */
    public function track_shipment($awb) {
        try {
            if (!$this->jne_client) {
                throw new Exception('JNE client not initialized. Check API credentials.');
            }

            $response = $this->jne_client->tracking($awb);
            
            if (!isset($response['history']) || empty($response['history'])) {
                throw new Exception('No tracking information available.');
            }

            return $response;

        } catch (Exception $e) {
            error_log('JNE API Error: ' . $e->getMessage());
            return false;
        }
    }
}
