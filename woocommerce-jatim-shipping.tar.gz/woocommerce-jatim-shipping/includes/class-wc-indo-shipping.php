<?php
/**
 * JNE Shipping Method Class for WooCommerce
 * Using yusufthedragon/jne-php package
 */

if (!defined('ABSPATH')) {
    exit;
}

class WC_Indo_Shipping_Method extends WC_Shipping_Method {
    /**
     * Constructor for shipping class
     */
    public function __construct($instance_id = 0) {
        $this->id = 'jne_shipping';
        $this->instance_id = absint($instance_id);
        $this->method_title = __('JNE Shipping', 'indo-shipping');
        $this->method_description = __('JNE shipping method with Jawa Timur restrictions', 'indo-shipping');
        $this->supports = array(
            'shipping-zones',
            'instance-settings',
            'instance-settings-modal',
        );

        $this->init();
    }

    /**
     * Initialize shipping method
     */
    public function init() {
        // Load the settings
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->title = $this->get_option('title');
        $this->enabled = $this->get_option('enabled');

        // Actions
        add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
    }

    /**
     * Initialize form fields
     */
    public function init_form_fields() {
        $this->instance_form_fields = array(
            'enabled' => array(
                'title' => __('Enable', 'indo-shipping'),
                'type' => 'checkbox',
                'label' => __('Enable this shipping method', 'indo-shipping'),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => __('Title', 'indo-shipping'),
                'type' => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'indo-shipping'),
                'default' => __('Indonesian Shipping', 'indo-shipping'),
                'desc_tip' => true
            ),
            'shipping_services' => array(
                'title' => __('JNE Services', 'indo-shipping'),
                'type' => 'multiselect',
                'description' => __('Select which JNE services to enable', 'indo-shipping'),
                'default' => array('reg', 'yes', 'oke'),
                'options' => array(
                    'reg' => 'JNE REG (Regular)',
                    'yes' => 'JNE YES (Yakin Esok Sampai)',
                    'oke' => 'JNE OKE (Ongkos Kirim Ekonomis)'
                ),
                'desc_tip' => true
            ),
            'handling_fee' => array(
                'title' => __('Handling Fee', 'indo-shipping'),
                'type' => 'number',
                'description' => __('Additional handling fee for shipping.', 'indo-shipping'),
                'default' => '0',
                'custom_attributes' => array(
                    'min' => '0',
                    'step' => '1000'
                ),
                'desc_tip' => true
            ),
            'show_delivery_time' => array(
                'title' => __('Show Delivery Time', 'indo-shipping'),
                'type' => 'checkbox',
                'label' => __('Show estimated delivery time', 'indo-shipping'),
                'default' => 'yes',
                'description' => __('This will show estimated delivery time for each shipping option.', 'indo-shipping')
            )
        );
    }

    /**
     * Calculate shipping rates
     */
    public function calculate_shipping($package = array()) {
        $settings = get_option('jne_shipping_settings');
        
        // Check if zone restriction is enabled
        if (!empty($settings['enable_zone_restriction'])) {
            if (!$this->is_jawa_timur($package['destination'])) {
                return;
            }
        }

        // Initialize JNE API handler
        $api = new Indo_Shipping_API(
            $settings['jne_api_key'] ?? '',
            $settings['jne_username'] ?? ''
        );

        // Calculate total weight
        $weight = 0;
        foreach ($package['contents'] as $item) {
            $product = $item['data'];
            $weight += (float)$product->get_weight() * $item['quantity'];
        }

        // Get settings and enabled services
        $enabled_services = $this->get_option('shipping_services', array());
        $base_handling_fee = (float)$this->get_option('handling_fee', 0);
        $jatim_handling_fee = (float)$settings['handling_fee_jatim'] ?? 0;
        $handling_fee = $base_handling_fee + $jatim_handling_fee;
        $show_delivery_time = $this->get_option('show_delivery_time') === 'yes';

        // Get JNE rates
        $rates = $api->get_cached_rates(
            $settings['origin_code'],
            $package['destination']['city'],
            $weight,
            'jne'
        );

        if (!$rates) {
            $rates = $api->get_jne_rates(
                $settings['origin_code'],
                $package['destination']['city'],
                $weight
            );

            if ($rates) {
                $api->set_cached_rates(
                    $settings['origin_code'],
                    $package['destination']['city'],
                    $weight,
                    'jne',
                    $rates
                );
            }
        }

        if ($rates) {
            foreach ($rates as $service_code => $rate_data) {
                if (in_array($service_code, $enabled_services)) {
                    $label = $rate_data['service'];
                    if ($show_delivery_time && !empty($rate_data['etd'])) {
                        $label .= ' (' . $rate_data['etd'] . ')';
                    }
                    
                    $this->add_rate(array(
                        'id' => 'jne_' . $service_code,
                        'label' => $label,
                        'cost' => $rate_data['cost'] + $handling_fee,
                        'calc_tax' => 'per_order',
                        'meta_data' => array(
                            'service_code' => $service_code,
                            'etd' => $rate_data['etd'] ?? '',
                            'description' => $rate_data['description'] ?? ''
                        )
                    ));
                }
            }
        }
    }

    /**
     * Check if destination is in Jawa Timur with enhanced validation
     */
    private function is_jawa_timur($destination) {
        $settings = get_option('indo_shipping_settings');
        $api = new Indo_Shipping_API('', '');

        // Basic city validation
        if (!$api->validate_jawa_timur_address($destination['city'])) {
            return false;
        }

        // Check if city is in allowed cities
        if (!empty($settings['jatim_cities']) && !in_array($destination['city'], $settings['jatim_cities'])) {
            return false;
        }

        // District validation if enabled
        if (!empty($settings['enable_district_restriction']) && !empty($destination['address_2'])) {
            if (!$api->validate_jawa_timur_address($destination['city'], $destination['address_2'])) {
                return false;
            }
        }

        // Postal code validation if enabled
        if (!empty($settings['enable_postal_restriction']) && !empty($destination['postcode'])) {
            if (!$api->validate_jawa_timur_address($destination['city'], '', $destination['postcode'])) {
                return false;
            }
        }

        return true;
    }

}
