<?php
/**
 * Admin Settings for JNE Shipping
 */

if (!defined('ABSPATH')) {
    exit;
}

class Indo_Shipping_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'init_settings'));
        add_action('wp_ajax_test_jne_connection', array($this, 'test_jne_connection'));
    }

    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'JNE Shipping Settings',
            'JNE Shipping',
            'manage_woocommerce',
            'jne-shipping-settings',
            array($this, 'settings_page')
        );
    }

    public function init_settings() {
        register_setting('jne_shipping_options', 'jne_shipping_settings');

        // API Configuration Section
        add_settings_section(
            'jne_api_settings',
            'JNE API Configuration',
            array($this, 'section_api_callback'),
            'jne-shipping-settings'
        );

        add_settings_field(
            'jne_api_key',
            'JNE API Key',
            array($this, 'text_field_callback'),
            'jne-shipping-settings',
            'jne_api_settings',
            array('field' => 'jne_api_key')
        );

        add_settings_field(
            'jne_username',
            'JNE Username',
            array($this, 'text_field_callback'),
            'jne-shipping-settings',
            'jne_api_settings',
            array('field' => 'jne_username')
        );

        // Origin Settings Section
        add_settings_section(
            'jne_origin_settings',
            'Origin Settings',
            array($this, 'section_origin_callback'),
            'jne-shipping-settings'
        );

        add_settings_field(
            'origin_code',
            'Origin City Code',
            array($this, 'origin_field_callback'),
            'jne-shipping-settings',
            'jne_origin_settings'
        );

        // Zone Settings Section
        add_settings_section(
            'jne_zone_settings',
            'Jawa Timur Zone Settings',
            array($this, 'section_zones_callback'),
            'jne-shipping-settings'
        );

        add_settings_field(
            'enable_zone_restriction',
            'Enable Jawa Timur Restriction',
            array($this, 'checkbox_field_callback'),
            'jne-shipping-settings',
            'jne_zone_settings',
            array('field' => 'enable_zone_restriction')
        );

        add_settings_field(
            'jatim_cities',
            'Allowed Cities',
            array($this, 'cities_field_callback'),
            'jne-shipping-settings',
            'jne_zone_settings'
        );

        add_settings_field(
            'enable_district_restriction',
            'Enable District Restriction',
            array($this, 'checkbox_field_callback'),
            'jne-shipping-settings',
            'jne_zone_settings',
            array('field' => 'enable_district_restriction')
        );

        add_settings_field(
            'enable_postal_restriction',
            'Enable Postal Code Restriction',
            array($this, 'checkbox_field_callback'),
            'jne-shipping-settings',
            'jne_zone_settings',
            array('field' => 'enable_postal_restriction')
        );

        add_settings_field(
            'handling_fee_jatim',
            'Jawa Timur Handling Fee',
            array($this, 'number_field_callback'),
            'jne-shipping-settings',
            'jne_zone_settings',
            array(
                'field' => 'handling_fee_jatim',
                'description' => 'Additional handling fee for deliveries within Jawa Timur (in IDR)'
            )
        );
    }

    public function section_api_callback() {
        echo '<p>Configure your JNE API credentials. Get your API key from <a href="https://www.jne.co.id/id/developer/api" target="_blank">JNE Developer Portal</a>.</p>';
    }

    public function section_origin_callback() {
        echo '<p>Set your shipping origin location.</p>';
    }

    public function section_zones_callback() {
        echo '<p>Configure shipping zone restrictions and settings for Jawa Timur area.</p>';
        echo '<p>Enable specific restrictions and set handling fees for deliveries within Jawa Timur.</p>';
    }

    public function cities_field_callback() {
        $options = get_option('jne_shipping_settings');
        $selected_cities = isset($options['jatim_cities']) ? $options['jatim_cities'] : array();
        
        $api = new Indo_Shipping_API('', '');
        $cities = $api->get_jawa_timur_cities();
        
        echo '<select id="jatim_cities" name="jne_shipping_settings[jatim_cities][]" multiple class="regular-text" style="height: 150px;">';
        foreach ($cities as $city) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($city),
                in_array($city, $selected_cities) ? 'selected="selected"' : '',
                esc_html($city)
            );
        }
        echo '</select>';
        echo '<p class="description">Hold Ctrl/Cmd to select multiple cities</p>';
    }

    public function number_field_callback($args) {
        $options = get_option('jne_shipping_settings');
        $field = $args['field'];
        $value = isset($options[$field]) ? $options[$field] : '0';
        
        printf(
            '<input type="number" id="%s" name="jne_shipping_settings[%s]" value="%s" class="regular-text" min="0" step="1000" />',
            esc_attr($field),
            esc_attr($field),
            esc_attr($value)
        );
        
        if (isset($args['description'])) {
            printf('<p class="description">%s</p>', esc_html($args['description']));
        }
    }

    public function text_field_callback($args) {
        $options = get_option('jne_shipping_settings');
        $field = $args['field'];
        $value = isset($options[$field]) ? $options[$field] : '';
        
        printf(
            '<input type="text" id="%s" name="jne_shipping_settings[%s]" value="%s" class="regular-text" />',
            esc_attr($field),
            esc_attr($field),
            esc_attr($value)
        );
    }

    public function origin_field_callback() {
        $options = get_option('jne_shipping_settings');
        $selected = isset($options['origin_code']) ? $options['origin_code'] : '';
        
        // Get JNE origins if API is configured
        $api = new Indo_Shipping_API(
            isset($options['jne_api_key']) ? $options['jne_api_key'] : '',
            isset($options['jne_username']) ? $options['jne_username'] : ''
        );
        
        $origins = $api->get_jne_origins();
        
        echo '<select id="origin_code" name="jne_shipping_settings[origin_code]" class="regular-text">';
        echo '<option value="">Select Origin City</option>';
        
        if ($origins) {
            foreach ($origins as $origin) {
                printf(
                    '<option value="%s" %s>%s</option>',
                    esc_attr($origin['origin_code']),
                    selected($selected, $origin['origin_code'], false),
                    esc_html($origin['origin_name'])
                );
            }
        }
        
        echo '</select>';
    }

    public function checkbox_field_callback($args) {
        $options = get_option('jne_shipping_settings');
        $field = $args['field'];
        $checked = isset($options[$field]) ? $options[$field] : '0';
        
        printf(
            '<input type="checkbox" id="%s" name="jne_shipping_settings[%s]" value="1" %s />',
            esc_attr($field),
            esc_attr($field),
            checked($checked, '1', false)
        );
    }

    public function settings_page() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form action="options.php" method="post">
                <?php
                settings_fields('jne_shipping_options');
                do_settings_sections('jne-shipping-settings');
                submit_button('Save Settings');
                ?>
            </form>

            <div class="card">
                <h2>Test API Connection</h2>
                <p>Click the button below to test your JNE API connection:</p>
                <button type="button" class="button button-secondary" id="test-jne-connection">
                    Test Connection
                </button>
                <div id="test-result" style="margin-top: 10px;"></div>
            </div>

            <div class="card">
                <h2>Supported Cities in Jawa Timur</h2>
                <p>The following cities are supported for shipping when zone restriction is enabled:</p>
                <ul style="list-style-type: disc; margin-left: 20px;">
                    <?php
                    $api = new Indo_Shipping_API('', '');
                    $cities = array_keys($api->get_jne_destinations());
                    foreach ($cities as $city) {
                        if ($api->validate_jawa_timur_address($city)) {
                            echo '<li>' . esc_html($city) . '</li>';
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#test-jne-connection').on('click', function() {
                var button = $(this);
                var result = $('#test-result');
                
                button.prop('disabled', true);
                result.html('<span style="color: #666;">Testing connection...</span>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'test_jne_connection',
                        nonce: '<?php echo wp_create_nonce("test-jne-connection"); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            result.html('<span style="color: green;">Connection successful!</span>');
                        } else {
                            result.html('<span style="color: red;">Connection failed: ' + response.data + '</span>');
                        }
                    },
                    error: function() {
                        result.html('<span style="color: red;">Connection test failed.</span>');
                    },
                    complete: function() {
                        button.prop('disabled', false);
                    }
                });
            });
        });
        </script>
        <?php
    }

    public function test_jne_connection() {
        check_ajax_referer('test-jne-connection', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('jne_shipping_settings');
        $api = new Indo_Shipping_API(
            isset($settings['jne_api_key']) ? $settings['jne_api_key'] : '',
            isset($settings['jne_username']) ? $settings['jne_username'] : ''
        );
        
        // Test by getting origin cities
        $origins = $api->get_jne_origins();
        
        if ($origins) {
            wp_send_json_success('Successfully connected to JNE API');
        } else {
            wp_send_json_error('Failed to connect to JNE API. Please check your credentials.');
        }
    }
}

// Initialize admin settings
new Indo_Shipping_Admin();
