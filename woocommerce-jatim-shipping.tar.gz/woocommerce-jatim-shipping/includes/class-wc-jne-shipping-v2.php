<?php
/**
 * JNE Shipping Method Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class WC_JNE_Shipping_Method extends WC_Shipping_Method {
    /**
     * Constructor for shipping class
     */
    public function __construct($instance_id = 0) {
        $this->id = 'jne_shipping';
        $this->instance_id = absint($instance_id);
        $this->method_title = __('JNE Shipping', 'indo-shipping');
        $this->method_description = __('JNE shipping integration with support for REG, YES, and OKE services', 'indo-shipping');
        $this->supports = array(
            'shipping-zones',
            'instance-settings',
            'instance-settings-modal',
        );

        $this->init();

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');

        // Actions
        add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
    }

    /**
     * Initialize settings fields
     */
    public function init_form_fields() {
        $this->instance_form_fields = array(
            'enabled' => array(
                'title' => __('Enable', 'indo-shipping'),
                'type' => 'checkbox',
                'label' => __('Enable this shipping method', 'indo-shipping'),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => __('Title', 'indo-shipping'),
                'type' => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'indo-shipping'),
                'default' => __('JNE Shipping', 'indo-shipping'),
                'desc_tip' => true
            ),
            'api_key' => array(
                'title' => __('JNE API Key', 'indo-shipping'),
                'type' => 'text',
                'description' => __('Enter your JNE API key. Get it from JNE Developer Portal.', 'indo-shipping'),
                'default' => '',
                'desc_tip' => true
            ),
            'username' => array(
                'title' => __('JNE Username', 'indo-shipping'),
                'type' => 'text',
                'description' => __('Enter your JNE username.', 'indo-shipping'),
                'default' => '',
                'desc_tip' => true
            ),
            'origin_city' => array(
                'title' => __('Origin City', 'indo-shipping'),
                'type' => 'text',
                'description' => __('Enter your origin city code (e.g., CGK10000 for Jakarta).', 'indo-shipping'),
                'default' => '',
                'desc_tip' => true
            ),
            'services' => array(
                'title' => __('JNE Services', 'indo-shipping'),
                'type' => 'multiselect',
                'description' => __('Select which JNE services to enable.', 'indo-shipping'),
                'default' => array('reg', 'yes', 'oke'),
                'options' => array(
                    'reg' => 'REG (Regular)',
                    'yes' => 'YES (Yakin Esok Sampai)',
                    'oke' => 'OKE (Ongkos Kirim Ekonomis)'
                ),
                'desc_tip' => true
            ),
            'handling_fee' => array(
                'title' => __('Handling Fee', 'indo-shipping'),
                'type' => 'number',
                'description' => __('Additional fee added to shipping cost.', 'indo-shipping'),
                'default' => '0',
                'custom_attributes' => array(
                    'min' => '0',
                    'step' => '1000'
                ),
                'desc_tip' => true
            ),
            'show_delivery_time' => array(
                'title' => __('Show Delivery Time', 'indo-shipping'),
                'type' => 'checkbox',
                'label' => __('Show estimated delivery time', 'indo-shipping'),
                'default' => 'yes'
            ),
            'debug_mode' => array(
                'title' => __('Debug Mode', 'indo-shipping'),
                'type' => 'checkbox',
                'label' => __('Enable debug mode', 'indo-shipping'),
                'default' => 'no',
                'description' => __('Log API requests and responses for debugging.', 'indo-shipping')
            )
        );
    }

    /**
     * Calculate shipping rates
     */
    public function calculate_shipping($package = array()) {
        // Check if shipping method is enabled
        if ($this->enabled !== 'yes') {
            return;
        }

        // Check if required settings are configured
        if (empty($this->settings['api_key']) || empty($this->settings['username']) || empty($this->settings['origin_city'])) {
            $this->debug_log('Missing required settings (API Key, Username, or Origin City)');
            return;
        }

        // Check if destination is provided
        if (empty($package['destination']['city'])) {
            $this->debug_log('No destination city provided');
            return;
        }

        // Calculate total weight
        $weight = 0;
        foreach ($package['contents'] as $item) {
            $product = $item['data'];
            $weight += (float)$product->get_weight() * $item['quantity'];
        }

        if ($weight <= 0) {
            $this->debug_log('Invalid package weight: ' . $weight);
            return;
        }

        try {
            // Initialize API
            $api = new Indo_Shipping_API(
                $this->settings['api_key'],
                $this->settings['username']
            );

            // Get shipping rates
            $rates = $api->get_jne_rates(
                $this->settings['origin_city'],
                $package['destination']['city'],
                $weight
            );

            if (!$rates) {
                $this->debug_log('No rates returned from JNE API');
                return;
            }

            // Add rates to WooCommerce
            $enabled_services = $this->get_option('services', array());
            $handling_fee = floatval($this->get_option('handling_fee', 0));
            $show_delivery_time = $this->get_option('show_delivery_time') === 'yes';

            foreach ($rates as $service_code => $rate_data) {
                if (!in_array($service_code, $enabled_services)) {
                    continue;
                }

                $label = $rate_data['service'];
                if ($show_delivery_time && !empty($rate_data['etd'])) {
                    $label .= ' (' . $rate_data['etd'] . ')';
                }

                $rate = array(
                    'id' => $this->id . ':' . $service_code,
                    'label' => $label,
                    'cost' => $rate_data['cost'] + $handling_fee,
                    'calc_tax' => 'per_order',
                    'meta_data' => array(
                        'service_code' => $service_code,
                        'etd' => $rate_data['etd'] ?? '',
                        'description' => $rate_data['description'] ?? ''
                    )
                );

                $this->add_rate($rate);
            }

        } catch (Exception $e) {
            $this->debug_log('Error calculating shipping: ' . $e->getMessage());
            return;
        }
    }

    /**
     * Debug log
     */
    private function debug_log($message) {
        if ($this->get_option('debug_mode') === 'yes') {
            if (is_array($message) || is_object($message)) {
                $message = print_r($message, true);
            }
            wc_get_logger()->debug($message, array('source' => 'jne-shipping'));
        }
    }
}
