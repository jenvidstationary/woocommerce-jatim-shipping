<?php
/**
 * Jawa Timur Zone Handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class Jawa_Timur_Zones {
    private $zones = array(
        'SUB' => array(
            'name' => 'Surabaya',
            'districts' => array(
                'Tegalsari', 'Genteng', 'Bubutan', 'Simokerto', 'Pabean Cantian',
                'Semampir', 'Krembangan', 'Kenjeran', 'Bulak', 'Tambaksari',
                'Gubeng', 'Rungkut', 'Tenggilis Mejoyo', 'Gunung Anyar', 'Sukolilo',
                'Mulyorejo', 'Sawahan', 'Wonokromo', 'Karangpilang', 'Dukuh Pakis',
                'Wiyung', 'Wonocolo', 'Gayungan', 'Jambangan', 'Tandes',
                'Sukomanunggal', 'Asemrowo', 'Benowo', 'Pakal', 'Lakarsantri',
                'Sambikerep'
            ),
            'postal_codes' => array(
                '60111', '60112', '60113', '60114', '60115', '60116', '60117',
                '60118', '60119', '60121', '60122', '60123', '60124', '60125',
                '60126', '60127', '60128', '60129', '60131', '60132', '60133',
                '60134', '60135', '60136', '60137', '60138', '60139'
            )
        ),
        'MLG' => array(
            'name' => 'Malang',
            'districts' => array(
                'Blimbing', 'Klojen', 'Kedungkandang', 'Sukun', 'Lowokwaru'
            ),
            'postal_codes' => array(
                '65111', '65112', '65113', '65114', '65115', '65116', '65117',
                '65118', '65119', '65121', '65122', '65123', '65124', '65125',
                '65126', '65127', '65128', '65129', '65131', '65132', '65133',
                '65134', '65135', '65136', '65137', '65138', '65139'
            )
        ),
        // Add more cities here
    );

    /**
     * Validate if address is in Jawa Timur with detailed checking
     */
    public function validate_address($city, $district = '', $postal_code = '') {
        // First check if city exists in our zones
        $city_key = $this->get_city_key($city);
        if (!$city_key) {
            return false;
        }

        // If district is provided, validate it
        if (!empty($district) && !in_array($district, $this->zones[$city_key]['districts'])) {
            return false;
        }

        // If postal code is provided, validate it
        if (!empty($postal_code) && !in_array($postal_code, $this->zones[$city_key]['postal_codes'])) {
            return false;
        }

        return true;
    }

    /**
     * Get city key from city name
     */
    private function get_city_key($city) {
        foreach ($this->zones as $key => $zone) {
            if (strcasecmp($zone['name'], $city) === 0) {
                return $key;
            }
        }
        return false;
    }

    /**
     * Get all supported districts for a city
     */
    public function get_districts($city) {
        $city_key = $this->get_city_key($city);
        return $city_key ? $this->zones[$city_key]['districts'] : array();
    }

    /**
     * Get all supported postal codes for a city
     */
    public function get_postal_codes($city) {
        $city_key = $this->get_city_key($city);
        return $city_key ? $this->zones[$city_key]['postal_codes'] : array();
    }

    /**
     * Get all supported cities
     */
    public function get_supported_cities() {
        $cities = array();
        foreach ($this->zones as $zone) {
            $cities[] = $zone['name'];
        }
        return $cities;
    }
}
