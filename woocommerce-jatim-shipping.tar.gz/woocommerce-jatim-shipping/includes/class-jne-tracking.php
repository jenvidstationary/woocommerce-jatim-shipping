<?php
/**
 * JNE Tracking Handler
 */

if (!defined('ABSPATH')) {
    exit;
}

class JNE_Tracking {
    private $config;
    private $api;

    /**
     * Constructor
     */
    public function __construct() {
        $this->config = JNE_Config::get_instance();
        $this->init_api();
        $this->init_hooks();
    }

    /**
     * Initialize API
     */
    private function init_api() {
        $api_config = $this->config->get_api_config();
        $this->api = new Indo_Shipping_API(
            $api_config['api_key'],
            $api_config['username']
        );
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Add tracking info to order details
        add_action('woocommerce_order_details_after_order_table', array($this, 'display_tracking_info'));
        
        // Add tracking info to emails
        add_action('woocommerce_email_after_order_table', array($this, 'display_tracking_info'));
        
        // Add tracking meta box to order admin
        add_action('add_meta_boxes', array($this, 'add_tracking_meta_box'));
        
        // Save tracking number
        add_action('woocommerce_process_shop_order_meta', array($this, 'save_tracking_number'));
        
        // AJAX tracking update
        add_action('wp_ajax_jne_update_tracking', array($this, 'ajax_update_tracking'));
        add_action('wp_ajax_nopriv_jne_update_tracking', array($this, 'ajax_update_tracking'));
    }

    /**
     * Display tracking information
     */
    public function display_tracking_info($order) {
        $tracking_number = $this->get_tracking_number($order);
        if (!$tracking_number) {
            return;
        }

        $tracking_info = $this->get_tracking_info($tracking_number);
        if (!$tracking_info) {
            return;
        }

        wc_get_template(
            'tracking-info.php',
            array(
                'tracking_number' => $tracking_number,
                'tracking_info' => $tracking_info
            ),
            '',
            JNE_SHIPPING_PLUGIN_DIR . 'templates/'
        );
    }

    /**
     * Add tracking meta box
     */
    public function add_tracking_meta_box() {
        add_meta_box(
            'jne-tracking-info',
            __('JNE Tracking Information', 'indo-shipping'),
            array($this, 'render_tracking_meta_box'),
            'shop_order',
            'side',
            'default'
        );
    }

    /**
     * Render tracking meta box
     */
    public function render_tracking_meta_box($post) {
        $order = wc_get_order($post->ID);
        $tracking_number = $this->get_tracking_number($order);
        $tracking_info = $tracking_number ? $this->get_tracking_info($tracking_number) : false;
        
        ?>
        <div class="jne-tracking-meta-box">
            <p>
                <label for="jne_tracking_number"><?php _e('Tracking Number:', 'indo-shipping'); ?></label>
                <input type="text" 
                       id="jne_tracking_number" 
                       name="jne_tracking_number" 
                       value="<?php echo esc_attr($tracking_number); ?>" 
                       class="widefat" />
            </p>
            
            <?php if ($tracking_number && $tracking_info): ?>
                <div class="tracking-status">
                    <p><strong><?php _e('Status:', 'indo-shipping'); ?></strong> 
                       <?php echo esc_html($tracking_info['status']); ?></p>
                    
                    <?php if (!empty($tracking_info['history'])): ?>
                        <div class="tracking-history">
                            <strong><?php _e('History:', 'indo-shipping'); ?></strong>
                            <ul>
                                <?php foreach ($tracking_info['history'] as $history): ?>
                                    <li>
                                        <span class="date"><?php echo esc_html($history['date']); ?></span>
                                        <span class="desc"><?php echo esc_html($history['desc']); ?></span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
                
                <p>
                    <button type="button" 
                            class="button update-tracking" 
                            data-order="<?php echo esc_attr($order->get_id()); ?>"
                            data-nonce="<?php echo wp_create_nonce('update-tracking-' . $order->get_id()); ?>">
                        <?php _e('Update Tracking', 'indo-shipping'); ?>
                    </button>
                </p>
            <?php endif; ?>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('.update-tracking').on('click', function() {
                var button = $(this);
                var order_id = button.data('order');
                var nonce = button.data('nonce');
                
                button.prop('disabled', true);
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'jne_update_tracking',
                        order_id: order_id,
                        nonce: nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            alert(response.data);
                        }
                    },
                    error: function() {
                        alert('<?php _e('Failed to update tracking information', 'indo-shipping'); ?>');
                    },
                    complete: function() {
                        button.prop('disabled', false);
                    }
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Save tracking number
     */
    public function save_tracking_number($order_id) {
        if (isset($_POST['jne_tracking_number'])) {
            $tracking_number = sanitize_text_field($_POST['jne_tracking_number']);
            $this->update_tracking_number($order_id, $tracking_number);
        }
    }

    /**
     * Handle AJAX tracking update
     */
    public function ajax_update_tracking() {
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        
        if (!$order_id || !check_ajax_referer('update-tracking-' . $order_id, 'nonce', false)) {
            wp_send_json_error(__('Invalid request', 'indo-shipping'));
        }

        $tracking_number = $this->get_tracking_number($order_id);
        if (!$tracking_number) {
            wp_send_json_error(__('No tracking number found', 'indo-shipping'));
        }

        $tracking_info = $this->get_tracking_info($tracking_number, true);
        if (!$tracking_info) {
            wp_send_json_error(__('Failed to get tracking information', 'indo-shipping'));
        }

        wp_send_json_success();
    }

    /**
     * Get tracking number
     */
    public function get_tracking_number($order) {
        $order_id = is_object($order) ? $order->get_id() : intval($order);
        return get_post_meta($order_id, '_jne_tracking_number', true);
    }

    /**
     * Update tracking number
     */
    public function update_tracking_number($order_id, $tracking_number) {
        if (empty($tracking_number)) {
            delete_post_meta($order_id, '_jne_tracking_number');
            delete_post_meta($order_id, '_jne_tracking_info');
        } else {
            update_post_meta($order_id, '_jne_tracking_number', $tracking_number);
            
            // Get fresh tracking info
            $tracking_info = $this->get_tracking_info($tracking_number, true);
            if ($tracking_info) {
                update_post_meta($order_id, '_jne_tracking_info', $tracking_info);
            }
        }
    }

    /**
     * Get tracking information
     */
    public function get_tracking_info($tracking_number, $force_refresh = false) {
        if (!$tracking_number) {
            return false;
        }

        try {
            if (!$force_refresh) {
                // Try to get cached info
                $cached_info = get_transient('jne_tracking_' . $tracking_number);
                if ($cached_info !== false) {
                    return $cached_info;
                }
            }

            // Get fresh tracking info
            $tracking_info = $this->api->track_shipment($tracking_number);
            
            if ($tracking_info) {
                // Cache for 1 hour
                set_transient('jne_tracking_' . $tracking_number, $tracking_info, HOUR_IN_SECONDS);
                return $tracking_info;
            }

            return false;

        } catch (Exception $e) {
            $this->config->log('Tracking error: ' . $e->getMessage(), 'error');
            return false;
        }
    }

    /**
     * Format tracking status
     */
    public function format_tracking_status($status) {
        $statuses = array(
            'delivered' => __('Delivered', 'indo-shipping'),
            'in_transit' => __('In Transit', 'indo-shipping'),
            'picked_up' => __('Picked Up', 'indo-shipping'),
            'pending' => __('Pending', 'indo-shipping')
        );

        return isset($statuses[$status]) ? $statuses[$status] : $status;
    }
}
