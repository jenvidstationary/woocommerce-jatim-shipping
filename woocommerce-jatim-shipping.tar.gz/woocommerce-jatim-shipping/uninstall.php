<?php
/**
 * JNE Shipping Uninstall
 *
 * Uninstalling JNE Shipping deletes options, tables, and other plugin data.
 */

// Exit if uninstall not called from WordPress
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Load main plugin file
require_once 'jne-shipping.php';

/**
 * Delete options
 */
delete_option('jne_shipping_settings');
delete_option('jne_shipping_version');

/**
 * Delete transients
 */
global $wpdb;

// Delete rate cache transients
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_jne_rate_%'");
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_jne_rate_%'");

// Delete tracking cache transients
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_jne_tracking_%'");
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_jne_tracking_%'");

/**
 * Delete post meta
 */
$wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_jne_%'");

/**
 * Remove uploaded files
 */
$upload_dir = wp_upload_dir();
$jne_dir = $upload_dir['basedir'] . '/jne-shipping';

if (is_dir($jne_dir)) {
    // Remove all files in the directory
    $files = glob($jne_dir . '/*');
    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file);
        }
    }
    // Remove directory
    rmdir($jne_dir);
}

/**
 * Remove logs
 */
$log_file = WP_CONTENT_DIR . '/debug-jne.log';
if (file_exists($log_file)) {
    unlink($log_file);
}

/**
 * Clear any cached data that has been removed
 */
wp_cache_flush();

/**
 * Flag to indicate this is a complete uninstall
 */
update_option('_jne_shipping_uninstalled', time());
